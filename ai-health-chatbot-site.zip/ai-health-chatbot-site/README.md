# AI-Powered Public Health Chatbot — Website

This is a simple, mobile-first static website for an AI-driven multilingual public health chatbot project.

## Contents
- `index.html` — main page
- `styles.css` — site styles
- `app.js` — minimal interactions and form handler
- `README.md` — this file

## Notes
- Replace placeholder phone numbers (`+919999999999`) with your deployment numbers.
- Integrate the contact form with your backend or Google Forms for production.
- Icons are inline SVG for a lightweight static site.
- The design uses blue/green colors and aims for clear readability in low-bandwidth contexts.

## License
MIT
