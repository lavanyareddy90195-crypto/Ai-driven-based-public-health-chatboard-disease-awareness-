document.addEventListener('DOMContentLoaded', function(){
  // Set current year
  document.getElementById('year').textContent = new Date().getFullYear();

  // Hook CTA buttons to the header phone numbers (replace with real numbers)
  const phone = '+919999999999';
  const waText = encodeURIComponent('Hello, I would like health information from the AI chatbot.');
  const whatsappLinks = [
    document.getElementById('whatsappBtn'),
    document.getElementById('heroWhatsapp')
  ];
  whatsappLinks.forEach(a => {
    if(a) a.href = `https://wa.me/${phone.replace('+','') }?text=${waText}`;
  });

  const smsLinks = [
    document.getElementById('smsBtn'),
    document.getElementById('heroSms')
  ];
  smsLinks.forEach(a => {
    if(a) a.href = `sms:${phone}?body=${waText}`;
  });

  // Simple contact form handler - in real deployment hook to backend/API
  const form = document.getElementById('contactForm');
  const status = document.getElementById('formStatus');
  form.addEventListener('submit', function(e){
    e.preventDefault();
    const data = new FormData(form);
    const payload = {};
    for(const [k,v] of data.entries()) payload[k]=v;
    // Simulate submission
    status.textContent = 'Sending...';
    setTimeout(()=> {
      status.textContent = 'Thanks — your message has been noted. We will contact you shortly.';
      form.reset();
    }, 800);
  });

  // Accessibility: enable keyboard focus styles on buttons when tabbing
  document.body.addEventListener('keydown', function(e){
    if(e.key === 'Tab') document.body.classList.add('user-is-tabbing');
  });

});
